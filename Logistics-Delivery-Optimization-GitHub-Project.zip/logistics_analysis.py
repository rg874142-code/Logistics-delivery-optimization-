import pandas as pd
import matplotlib.pyplot as plt

data = pd.read_csv("logistics_data.csv")

print("First 5 records:")
print(data.head())
print("\nMissing values:")
print(data.isnull().sum())

total = len(data)
on_time = (data["Delivery_Status"] == "On-Time").sum()
on_time_rate = on_time / total * 100
avg_cost = data["Delivery_Cost"].mean()

print(f"\nOn-Time Delivery Rate: {on_time_rate:.2f}%")
print(f"Average Delivery Cost: ₹{avg_cost:.2f}")
print(f"Average Distance: {data['Distance_km'].mean():.2f} km")

# Delivery status
data["Delivery_Status"].value_counts().plot(kind="bar")
plt.title("Delivery Status Analysis")
plt.xlabel("Status")
plt.ylabel("Number of Orders")
plt.tight_layout()
plt.savefig("graphs/delivery_status.png")
plt.close()

# Cost by warehouse
data.groupby("Warehouse")["Delivery_Cost"].mean().plot(kind="bar")
plt.title("Average Delivery Cost by Warehouse")
plt.xlabel("Warehouse")
plt.ylabel("Average Cost")
plt.tight_layout()
plt.savefig("graphs/delivery_cost.png")
plt.close()

# Inventory vs demand
plt.scatter(data["Inventory_Level"], data["Demand"])
plt.title("Inventory Level vs Demand")
plt.xlabel("Inventory Level")
plt.ylabel("Demand")
plt.tight_layout()
plt.savefig("graphs/inventory_analysis.png")
plt.close()

print("\nAnalysis completed. Graphs saved in the graphs/ folder.")
